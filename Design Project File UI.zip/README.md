
  # Design Project File UI

  This is a code bundle for Design Project File UI. The original project is available at https://www.figma.com/design/b00Kq6a8VSvWG3oQBQo91E/Design-Project-File-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  