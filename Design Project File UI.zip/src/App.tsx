import { useState } from 'react';
import { Landing } from './components/Landing';
import { SignIn } from './components/SignIn';
import { SignUp } from './components/SignUp';
import { Dashboard } from './components/Dashboard';
import { CreateTeam } from './components/CreateTeam';
import { JoinTeam } from './components/JoinTeam';
import { TeamDetails } from './components/TeamDetails';
import { RequestedTeams } from './components/RequestedTeams';
import { CreatedTeams } from './components/CreatedTeams';
import { Notifications } from './components/Notifications';
import { Profile } from './components/Profile';
import { Settings } from './components/Settings';

export type User = {
  id: string;
  name: string;
  email: string;
  college: string;
  major: string;
  year: string;
  skills: string[];
  bio: string;
  avatar?: string;
};

export type Team = {
  id: string;
  name: string;
  hackathon: string;
  description: string;
  skills: string[];
  lookingFor: string[];
  members: User[];
  maxMembers: number;
  createdBy: string;
  createdAt: Date;
};

export type JoinRequest = {
  id: string;
  teamId: string;
  userId: string;
  user: User;
  message: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: Date;
};

type Page = 
  | 'landing' 
  | 'signin' 
  | 'signup' 
  | 'dashboard' 
  | 'create-team' 
  | 'join-team' 
  | 'team-details' 
  | 'requested-teams'
  | 'created-teams'
  | 'notifications'
  | 'profile'
  | 'settings';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('landing');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null);

  const handleNavigate = (page: Page, team?: Team) => {
    setCurrentPage(page);
    if (team) setSelectedTeam(team);
  };

  const handleSignIn = (user: User) => {
    setCurrentUser(user);
    setCurrentPage('dashboard');
  };

  const handleSignOut = () => {
    setCurrentUser(null);
    setCurrentPage('landing');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {currentPage === 'landing' && (
        <Landing onNavigate={handleNavigate} />
      )}
      {currentPage === 'signin' && (
        <SignIn onNavigate={handleNavigate} onSignIn={handleSignIn} />
      )}
      {currentPage === 'signup' && (
        <SignUp onNavigate={handleNavigate} onSignUp={handleSignIn} />
      )}
      {currentPage === 'dashboard' && currentUser && (
        <Dashboard 
          user={currentUser} 
          onNavigate={handleNavigate}
          onSignOut={handleSignOut}
        />
      )}
      {currentPage === 'create-team' && currentUser && (
        <CreateTeam 
          user={currentUser}
          onNavigate={handleNavigate}
          onSignOut={handleSignOut}
        />
      )}
      {currentPage === 'join-team' && currentUser && (
        <JoinTeam 
          user={currentUser}
          onNavigate={handleNavigate}
          onSignOut={handleSignOut}
        />
      )}
      {currentPage === 'team-details' && currentUser && selectedTeam && (
        <TeamDetails 
          user={currentUser}
          team={selectedTeam}
          onNavigate={handleNavigate}
          onSignOut={handleSignOut}
        />
      )}
      {currentPage === 'requested-teams' && currentUser && (
        <RequestedTeams 
          user={currentUser}
          onNavigate={handleNavigate}
          onSignOut={handleSignOut}
        />
      )}
      {currentPage === 'created-teams' && currentUser && (
        <CreatedTeams 
          user={currentUser}
          onNavigate={handleNavigate}
          onSignOut={handleSignOut}
        />
      )}
      {currentPage === 'notifications' && currentUser && (
        <Notifications 
          user={currentUser}
          onNavigate={handleNavigate}
          onSignOut={handleSignOut}
        />
      )}
      {currentPage === 'profile' && currentUser && (
        <Profile 
          user={currentUser}
          onNavigate={handleNavigate}
          onSignOut={handleSignOut}
        />
      )}
      {currentPage === 'settings' && currentUser && (
        <Settings 
          user={currentUser}
          onNavigate={handleNavigate}
          onSignOut={handleSignOut}
        />
      )}
    </div>
  );
}
