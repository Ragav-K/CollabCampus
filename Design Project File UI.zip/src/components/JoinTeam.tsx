import { useState } from 'react';
import { User, Team } from '../App';
import { Navigation } from './Navigation';
import { TeamCard } from './TeamCard';
import { Search, Filter, X } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

type JoinTeamProps = {
  user: User;
  onNavigate: (page: any, team?: Team) => void;
  onSignOut: () => void;
};

const mockTeams: Team[] = [
  {
    id: '1',
    name: 'AI Healthcare Innovators',
    hackathon: 'MIT Health Hack 2025',
    description: 'Building an AI-powered diagnostic assistant to help rural healthcare workers make better decisions with limited resources.',
    skills: ['Machine Learning', 'Python', 'Healthcare'],
    lookingFor: ['Backend Developer', 'UI/UX Designer'],
    members: [
      { id: '2', name: 'Sarah Chen', email: 'sarah@mit.edu', college: 'MIT', major: 'AI', year: 'Senior', skills: ['ML', 'Python'], bio: '' },
      { id: '3', name: 'Mike Wilson', email: 'mike@mit.edu', college: 'MIT', major: 'CS', year: 'Junior', skills: ['Python'], bio: '' },
    ],
    maxMembers: 4,
    createdBy: '2',
    createdAt: new Date('2025-01-10'),
  },
  {
    id: '2',
    name: 'Sustainable Campus',
    hackathon: 'Green Tech Challenge',
    description: 'Creating a platform to track and reduce carbon footprint on college campuses through gamification.',
    skills: ['React', 'Node.js', 'Data Viz'],
    lookingFor: ['Full Stack Developer'],
    members: [
      { id: '4', name: 'Emily Davis', email: 'emily@stanford.edu', college: 'Stanford', major: 'Environmental Science', year: 'Sophomore', skills: ['React'], bio: '' },
    ],
    maxMembers: 3,
    createdBy: '4',
    createdAt: new Date('2025-01-12'),
  },
  {
    id: '3',
    name: 'FinTech Wizards',
    hackathon: 'HackMoney 2025',
    description: 'Building a peer-to-peer lending platform for college students with transparent interest rates.',
    skills: ['Blockchain', 'Solidity', 'React'],
    lookingFor: ['Smart Contract Developer', 'Frontend Dev'],
    members: [
      { id: '5', name: 'James Lee', email: 'james@berkeley.edu', college: 'UC Berkeley', major: 'Finance', year: 'Junior', skills: ['Blockchain'], bio: '' },
      { id: '6', name: 'Lisa Park', email: 'lisa@berkeley.edu', college: 'UC Berkeley', major: 'CS', year: 'Senior', skills: ['Solidity'], bio: '' },
    ],
    maxMembers: 4,
    createdBy: '5',
    createdAt: new Date('2025-01-15'),
  },
  {
    id: '4',
    name: 'EduGame Builders',
    hackathon: 'Education Innovation Summit',
    description: 'Gamifying STEM education for middle school students with interactive puzzles and challenges.',
    skills: ['Unity', 'C#', 'Game Design'],
    lookingFor: ['Game Developer', '3D Artist'],
    members: [
      { id: '7', name: 'Tom Anderson', email: 'tom@ucla.edu', college: 'UCLA', major: 'Game Design', year: 'Senior', skills: ['Unity'], bio: '' },
    ],
    maxMembers: 4,
    createdBy: '7',
    createdAt: new Date('2025-01-14'),
  },
  {
    id: '5',
    name: 'Voice Assistant Pro',
    hackathon: 'AI Voice Hack',
    description: 'Creating an accessible voice assistant for visually impaired students navigating campus.',
    skills: ['NLP', 'Python', 'Mobile Dev'],
    lookingFor: ['iOS Developer', 'NLP Engineer'],
    members: [
      { id: '8', name: 'Rachel Kim', email: 'rachel@cornell.edu', college: 'Cornell', major: 'CS', year: 'Junior', skills: ['Python', 'NLP'], bio: '' },
      { id: '9', name: 'David Brown', email: 'david@cornell.edu', college: 'Cornell', major: 'Accessibility', year: 'Senior', skills: ['UX'], bio: '' },
    ],
    maxMembers: 4,
    createdBy: '8',
    createdAt: new Date('2025-01-11'),
  },
];

const hackathons = ['All Hackathons', 'MIT Health Hack 2025', 'Green Tech Challenge', 'HackMoney 2025', 'Education Innovation Summit', 'AI Voice Hack'];

export function JoinTeam({ user, onNavigate, onSignOut }: JoinTeamProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedHackathon, setSelectedHackathon] = useState<string>('All Hackathons');
  const [showFilters, setShowFilters] = useState(false);

  const filteredTeams = mockTeams.filter(team => {
    const matchesSearch = 
      team.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      team.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      team.lookingFor.some(role => role.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesHackathon = 
      selectedHackathon === 'All Hackathons' || 
      team.hackathon === selectedHackathon;

    return matchesSearch && matchesHackathon;
  });

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-8">
      <Navigation 
        user={user} 
        currentPage="join-team" 
        onNavigate={onNavigate}
        onSignOut={onSignOut}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-gray-900 mb-2">Find Teams</h1>
          <p className="text-gray-600">Discover hackathon teams looking for members like you</p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-6">
          <div className="flex gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                placeholder="Search by team name, role, or skills..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button
              variant={showFilters ? 'default' : 'outline'}
              onClick={() => setShowFilters(!showFilters)}
              className="gap-2"
            >
              <Filter className="w-4 h-4" />
              <span className="hidden sm:inline">Filters</span>
            </Button>
          </div>

          {/* Filter Panel */}
          {showFilters && (
            <div className="mt-4 pt-4 border-t">
              <div className="space-y-3">
                <div>
                  <label className="text-sm text-gray-700 mb-2 block">Hackathon</label>
                  <div className="flex flex-wrap gap-2">
                    {hackathons.map((hackathon) => (
                      <button
                        key={hackathon}
                        onClick={() => setSelectedHackathon(hackathon)}
                        className={`px-3 py-1.5 rounded-full text-sm transition-colors ${
                          selectedHackathon === hackathon
                            ? 'bg-[#1E90FF] text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        {hackathon}
                      </button>
                    ))}
                  </div>
                </div>

                {selectedHackathon !== 'All Hackathons' && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelectedHackathon('All Hackathons')}
                    className="gap-2"
                  >
                    <X className="w-4 h-4" />
                    Clear filters
                  </Button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Active Filters */}
        {(searchQuery || selectedHackathon !== 'All Hackathons') && (
          <div className="flex items-center gap-2 mb-4">
            <span className="text-sm text-gray-600">Active filters:</span>
            {searchQuery && (
              <Badge variant="secondary" className="gap-2">
                Search: {searchQuery}
                <button onClick={() => setSearchQuery('')}>
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            )}
            {selectedHackathon !== 'All Hackathons' && (
              <Badge variant="secondary" className="gap-2">
                {selectedHackathon}
                <button onClick={() => setSelectedHackathon('All Hackathons')}>
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            )}
          </div>
        )}

        {/* Results */}
        <div className="mb-4">
          <p className="text-sm text-gray-600">
            {filteredTeams.length} {filteredTeams.length === 1 ? 'team' : 'teams'} found
          </p>
        </div>

        {/* Teams Grid */}
        {filteredTeams.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredTeams.map((team) => (
              <TeamCard 
                key={team.id} 
                team={team}
                onClick={() => onNavigate('team-details', team)}
              />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-2xl p-12 text-center shadow-sm">
            <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-gray-900 mb-2">No teams found</h3>
            <p className="text-gray-600 mb-6">
              Try adjusting your filters or search terms
            </p>
            <Button
              variant="outline"
              onClick={() => {
                setSearchQuery('');
                setSelectedHackathon('All Hackathons');
              }}
            >
              Clear all filters
            </Button>
          </div>
        )}
      </main>
    </div>
  );
}
