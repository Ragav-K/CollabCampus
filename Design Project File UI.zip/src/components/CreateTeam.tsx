import { useState } from 'react';
import { User } from '../App';
import { Navigation } from './Navigation';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { X, Plus } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Alert, AlertDescription } from './ui/alert';
import { CheckCircle2 } from 'lucide-react';

type CreateTeamProps = {
  user: User;
  onNavigate: (page: any) => void;
  onSignOut: () => void;
};

export function CreateTeam({ user, onNavigate, onSignOut }: CreateTeamProps) {
  const [teamName, setTeamName] = useState('');
  const [hackathon, setHackathon] = useState('');
  const [description, setDescription] = useState('');
  const [maxMembers, setMaxMembers] = useState('4');
  const [lookingFor, setLookingFor] = useState<string[]>([]);
  const [newRole, setNewRole] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleAddRole = () => {
    if (newRole.trim() && !lookingFor.includes(newRole.trim())) {
      setLookingFor([...lookingFor, newRole.trim()]);
      setNewRole('');
    }
  };

  const handleRemoveRole = (role: string) => {
    setLookingFor(lookingFor.filter(r => r !== role));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate team creation
    setIsSubmitted(true);
    setTimeout(() => {
      onNavigate('created-teams');
    }, 2000);
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation 
          user={user} 
          currentPage="create-team" 
          onNavigate={onNavigate}
          onSignOut={onSignOut}
        />
        <main className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="bg-white rounded-2xl p-8 shadow-sm text-center">
            <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-gray-900 mb-2">Team Created Successfully! 🎉</h2>
            <p className="text-gray-600 mb-6">
              Your team "{teamName}" is now live. Students can start sending join requests!
            </p>
            <Button onClick={() => onNavigate('created-teams')}>
              View My Teams
            </Button>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-8">
      <Navigation 
        user={user} 
        currentPage="create-team" 
        onNavigate={onNavigate}
        onSignOut={onSignOut}
      />

      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-gray-900 mb-2">Create a New Team</h1>
          <p className="text-gray-600">Fill in the details to find your perfect teammates</p>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm">
          <div className="space-y-6">
            {/* Team Name */}
            <div className="space-y-2">
              <Label htmlFor="team-name">
                Team Name <span className="text-red-500">*</span>
              </Label>
              <Input
                id="team-name"
                placeholder="e.g., AI Healthcare Innovators"
                value={teamName}
                onChange={(e) => setTeamName(e.target.value)}
                required
              />
            </div>

            {/* Hackathon */}
            <div className="space-y-2">
              <Label htmlFor="hackathon">
                Hackathon / Event <span className="text-red-500">*</span>
              </Label>
              <Input
                id="hackathon"
                placeholder="e.g., MIT Health Hack 2025"
                value={hackathon}
                onChange={(e) => setHackathon(e.target.value)}
                required
              />
              <p className="text-xs text-gray-500">
                Which hackathon or event is this team for?
              </p>
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="description">
                Project Description <span className="text-red-500">*</span>
              </Label>
              <Textarea
                id="description"
                placeholder="Describe your project idea and what you're building..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={4}
                required
                className="resize-none"
              />
              <p className="text-xs text-gray-500">
                {description.length}/500 characters
              </p>
            </div>

            {/* Team Size */}
            <div className="space-y-2">
              <Label htmlFor="max-members">
                Maximum Team Size <span className="text-red-500">*</span>
              </Label>
              <Select value={maxMembers} onValueChange={setMaxMembers}>
                <SelectTrigger id="max-members">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2">2 members</SelectItem>
                  <SelectItem value="3">3 members</SelectItem>
                  <SelectItem value="4">4 members</SelectItem>
                  <SelectItem value="5">5 members</SelectItem>
                  <SelectItem value="6">6 members</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Looking For */}
            <div className="space-y-2">
              <Label htmlFor="looking-for">Roles You're Looking For</Label>
              <div className="flex gap-2">
                <Input
                  id="looking-for"
                  placeholder="e.g., Frontend Developer"
                  value={newRole}
                  onChange={(e) => setNewRole(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddRole();
                    }
                  }}
                />
                <Button 
                  type="button" 
                  onClick={handleAddRole}
                  variant="outline"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              {lookingFor.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-3">
                  {lookingFor.map((role) => (
                    <div
                      key={role}
                      className="inline-flex items-center gap-2 px-3 py-1 bg-blue-50 text-[#1E90FF] rounded-full text-sm"
                    >
                      <span>{role}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveRole(role)}
                        className="hover:bg-blue-100 rounded-full p-0.5"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
              <p className="text-xs text-gray-500">
                Add specific roles or skills you need on your team
              </p>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t flex flex-col sm:flex-row gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => onNavigate('dashboard')}
              className="sm:flex-1"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="sm:flex-1"
              disabled={!teamName || !hackathon || !description}
            >
              Create Team
            </Button>
          </div>
        </form>

        {/* Tips */}
        <Alert className="mt-6">
          <AlertDescription>
            <strong>💡 Pro Tips:</strong> Be specific about your project and the roles you need. 
            Teams with clear descriptions get 3x more quality join requests!
          </AlertDescription>
        </Alert>
      </main>
    </div>
  );
}
