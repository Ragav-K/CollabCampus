import { useState } from 'react';
import { User } from '../App';
import { Navigation } from './Navigation';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Edit2, GraduationCap, Mail, MapPin, Plus, X, Save } from 'lucide-react';

type ProfileProps = {
  user: User;
  onNavigate: (page: any) => void;
  onSignOut: () => void;
};

export function Profile({ user, onNavigate, onSignOut }: ProfileProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(user.name);
  const [bio, setBio] = useState(user.bio);
  const [major, setMajor] = useState(user.major);
  const [year, setYear] = useState(user.year);
  const [skills, setSkills] = useState(user.skills);
  const [newSkill, setNewSkill] = useState('');

  const handleAddSkill = () => {
    if (newSkill.trim() && !skills.includes(newSkill.trim())) {
      setSkills([...skills, newSkill.trim()]);
      setNewSkill('');
    }
  };

  const handleRemoveSkill = (skill: string) => {
    setSkills(skills.filter(s => s !== skill));
  };

  const handleSave = () => {
    // Save profile changes
    setIsEditing(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-8">
      <Navigation 
        user={user} 
        currentPage="profile" 
        onNavigate={onNavigate}
        onSignOut={onSignOut}
      />

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-gray-900">My Profile</h1>
          {!isEditing && (
            <Button onClick={() => setIsEditing(true)} className="gap-2">
              <Edit2 className="w-4 h-4" />
              Edit Profile
            </Button>
          )}
        </div>

        <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm">
          {/* Profile Header */}
          <div className="flex flex-col sm:flex-row items-start gap-6 mb-8 pb-8 border-b">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#1E90FF] to-[#0EA5A4] flex items-center justify-center flex-shrink-0">
              <span className="text-white text-4xl">{name.charAt(0)}</span>
            </div>
            <div className="flex-1">
              {isEditing ? (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                    />
                  </div>
                </div>
              ) : (
                <>
                  <h2 className="text-gray-900 mb-2">{name}</h2>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-3 text-gray-600 mb-4">
                    <div className="flex items-center gap-2">
                      <GraduationCap className="w-4 h-4" />
                      <span>{major} • {year}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      <span>{user.college}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <Mail className="w-4 h-4" />
                    <span>{user.email}</span>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Bio */}
          <div className="mb-8">
            <Label htmlFor="bio" className="mb-3 block">About Me</Label>
            {isEditing ? (
              <Textarea
                id="bio"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Tell teams about yourself, your interests, and what you're looking for..."
                rows={4}
                className="resize-none"
              />
            ) : (
              <p className="text-gray-700">
                {bio || 'No bio added yet. Click Edit Profile to add one.'}
              </p>
            )}
          </div>

          {/* Education */}
          {isEditing && (
            <div className="mb-8 grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="major">Major</Label>
                <Input
                  id="major"
                  value={major}
                  onChange={(e) => setMajor(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="year">Year</Label>
                <Input
                  id="year"
                  value={year}
                  onChange={(e) => setYear(e.target.value)}
                />
              </div>
            </div>
          )}

          {/* Skills */}
          <div>
            <Label className="mb-3 block">Skills & Interests</Label>
            {isEditing && (
              <div className="flex gap-2 mb-4">
                <Input
                  placeholder="Add a skill (e.g., React, Python)"
                  value={newSkill}
                  onChange={(e) => setNewSkill(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddSkill();
                    }
                  }}
                />
                <Button 
                  type="button" 
                  onClick={handleAddSkill}
                  variant="outline"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            )}
            {skills.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {skills.map((skill) => (
                  <Badge
                    key={skill}
                    variant="secondary"
                    className="text-sm"
                  >
                    {skill}
                    {isEditing && (
                      <button
                        type="button"
                        onClick={() => handleRemoveSkill(skill)}
                        className="ml-2 hover:bg-gray-300 rounded-full p-0.5"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    )}
                  </Badge>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-sm">
                No skills added yet. {isEditing ? 'Add your skills above.' : 'Click Edit Profile to add skills.'}
              </p>
            )}
          </div>

          {/* Action Buttons */}
          {isEditing && (
            <div className="mt-8 pt-8 border-t flex gap-3">
              <Button
                variant="outline"
                onClick={() => {
                  setIsEditing(false);
                  // Reset to original values
                  setName(user.name);
                  setBio(user.bio);
                  setMajor(user.major);
                  setYear(user.year);
                  setSkills(user.skills);
                }}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSave}
                className="flex-1 gap-2"
              >
                <Save className="w-4 h-4" />
                Save Changes
              </Button>
            </div>
          )}
        </div>

        {/* Stats */}
        {!isEditing && (
          <div className="mt-6 grid sm:grid-cols-3 gap-4">
            <div className="bg-white rounded-2xl p-6 shadow-sm text-center">
              <p className="text-3xl text-gray-900 mb-1">2</p>
              <p className="text-sm text-gray-600">Teams Created</p>
            </div>
            <div className="bg-white rounded-2xl p-6 shadow-sm text-center">
              <p className="text-3xl text-gray-900 mb-1">3</p>
              <p className="text-sm text-gray-600">Join Requests</p>
            </div>
            <div className="bg-white rounded-2xl p-6 shadow-sm text-center">
              <p className="text-3xl text-gray-900 mb-1">12</p>
              <p className="text-sm text-gray-600">Profile Views</p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
