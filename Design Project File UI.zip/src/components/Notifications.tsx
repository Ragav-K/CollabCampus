import { User } from '../App';
import { Navigation } from './Navigation';
import { Bell, Users, CheckCircle, XCircle, MessageSquare } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';

type NotificationsProps = {
  user: User;
  onNavigate: (page: any) => void;
  onSignOut: () => void;
};

type Notification = {
  id: string;
  type: 'request' | 'accepted' | 'rejected' | 'message';
  title: string;
  description: string;
  time: Date;
  isRead: boolean;
};

const mockNotifications: Notification[] = [
  {
    id: '1',
    type: 'request',
    title: 'New Join Request',
    description: 'Maya Patel wants to join your team "Campus Food Share"',
    time: new Date('2025-01-16T10:30:00'),
    isRead: false,
  },
  {
    id: '2',
    type: 'accepted',
    title: 'Request Accepted!',
    description: 'Your request to join "Sustainable Campus" was accepted',
    time: new Date('2025-01-15T14:20:00'),
    isRead: false,
  },
  {
    id: '3',
    type: 'request',
    title: 'New Join Request',
    description: 'Chris Taylor wants to join your team "Study Buddy AI"',
    time: new Date('2025-01-16T09:15:00'),
    isRead: false,
  },
  {
    id: '4',
    type: 'message',
    title: 'Team Update',
    description: 'Sarah Chen posted an update in "AI Healthcare Innovators"',
    time: new Date('2025-01-14T16:45:00'),
    isRead: true,
  },
  {
    id: '5',
    type: 'rejected',
    title: 'Request Declined',
    description: 'Your request to join "EduGame Builders" was declined',
    time: new Date('2025-01-13T11:30:00'),
    isRead: true,
  },
];

export function Notifications({ user, onNavigate, onSignOut }: NotificationsProps) {
  const unreadCount = mockNotifications.filter(n => !n.isRead).length;

  const getIcon = (type: Notification['type']) => {
    switch (type) {
      case 'request':
        return <Users className="w-5 h-5 text-blue-600" />;
      case 'accepted':
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'rejected':
        return <XCircle className="w-5 h-5 text-red-600" />;
      case 'message':
        return <MessageSquare className="w-5 h-5 text-purple-600" />;
    }
  };

  const getTimeAgo = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${diffDays}d ago`;
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-8">
      <Navigation 
        user={user} 
        currentPage="notifications" 
        onNavigate={onNavigate}
        onSignOut={onSignOut}
        notificationCount={0}
      />

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-gray-900 mb-2">Notifications</h1>
            {unreadCount > 0 && (
              <p className="text-gray-600">You have {unreadCount} unread notifications</p>
            )}
          </div>
          {mockNotifications.some(n => !n.isRead) && (
            <Button variant="ghost" size="sm">
              Mark all as read
            </Button>
          )}
        </div>

        {mockNotifications.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center shadow-sm">
            <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
              <Bell className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-gray-900 mb-2">No Notifications</h3>
            <p className="text-gray-600">
              You're all caught up! We'll notify you of any updates.
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {mockNotifications.map((notification) => (
              <div
                key={notification.id}
                className={`flex items-start gap-4 p-4 rounded-xl transition-colors cursor-pointer ${
                  notification.isRead
                    ? 'bg-white hover:bg-gray-50'
                    : 'bg-blue-50 hover:bg-blue-100'
                }`}
              >
                <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center flex-shrink-0">
                  {getIcon(notification.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <h3 className="text-gray-900">{notification.title}</h3>
                    {!notification.isRead && (
                      <Badge variant="secondary" className="bg-blue-600 text-white">
                        New
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{notification.description}</p>
                  <p className="text-xs text-gray-500">{getTimeAgo(notification.time)}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
