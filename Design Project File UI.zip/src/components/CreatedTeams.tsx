import { useState } from 'react';
import { User, Team, JoinRequest } from '../App';
import { Navigation } from './Navigation';
import { Users, Clock, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';

type CreatedTeamsProps = {
  user: User;
  onNavigate: (page: any, team?: Team) => void;
  onSignOut: () => void;
};

const mockTeams: Team[] = [
  {
    id: '1',
    name: 'Campus Food Share',
    hackathon: 'Social Good Hackathon',
    description: 'Connecting students with excess meal plans to those in need',
    skills: ['React', 'Firebase', 'Mobile'],
    lookingFor: ['Mobile Developer'],
    members: [
      { id: '1', name: 'Alex Johnson', email: 'alex@mit.edu', college: 'MIT', major: 'CS', year: 'Junior', skills: ['React'], bio: '' },
      { id: '10', name: 'Jordan Lee', email: 'jordan@mit.edu', college: 'MIT', major: 'Design', year: 'Sophomore', skills: ['UI/UX'], bio: '' },
    ],
    maxMembers: 4,
    createdBy: '1',
    createdAt: new Date('2025-01-08'),
  },
  {
    id: '2',
    name: 'Study Buddy AI',
    hackathon: 'EdTech Innovation 2025',
    description: 'AI-powered study companion that adapts to your learning style',
    skills: ['Python', 'ML', 'React'],
    lookingFor: ['Backend Developer', 'ML Engineer'],
    members: [
      { id: '1', name: 'Alex Johnson', email: 'alex@mit.edu', college: 'MIT', major: 'CS', year: 'Junior', skills: ['React'], bio: '' },
    ],
    maxMembers: 3,
    createdBy: '1',
    createdAt: new Date('2025-01-14'),
  },
];

const mockRequests: JoinRequest[] = [
  {
    id: '1',
    teamId: '1',
    userId: '11',
    user: {
      id: '11',
      name: 'Maya Patel',
      email: 'maya@stanford.edu',
      college: 'Stanford University',
      major: 'Computer Science',
      year: 'Junior',
      skills: ['React Native', 'Swift', 'Mobile Development'],
      bio: 'Passionate mobile developer with 2 years of iOS and Android experience',
    },
    message: 'Hi! I have extensive mobile development experience and would love to help build the app. I\'ve worked on similar social impact projects before.',
    status: 'pending',
    createdAt: new Date('2025-01-15'),
  },
  {
    id: '2',
    teamId: '2',
    userId: '12',
    user: {
      id: '12',
      name: 'Chris Taylor',
      email: 'chris@berkeley.edu',
      college: 'UC Berkeley',
      major: 'Data Science',
      year: 'Senior',
      skills: ['Python', 'TensorFlow', 'PyTorch'],
      bio: 'ML enthusiast specializing in NLP and personalization algorithms',
    },
    message: 'This project sounds amazing! I have experience building recommendation systems and would love to work on the AI adaptation features.',
    status: 'pending',
    createdAt: new Date('2025-01-16'),
  },
  {
    id: '3',
    teamId: '2',
    userId: '13',
    user: {
      id: '13',
      name: 'Sam Rivera',
      email: 'sam@mit.edu',
      college: 'MIT',
      major: 'Software Engineering',
      year: 'Sophomore',
      skills: ['Node.js', 'PostgreSQL', 'API Design'],
      bio: 'Backend specialist with focus on scalable systems',
    },
    message: 'I\'d be great for backend development. I have experience with building APIs and managing databases.',
    status: 'pending',
    createdAt: new Date('2025-01-15'),
  },
];

export function CreatedTeams({ user, onNavigate, onSignOut }: CreatedTeamsProps) {
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null);
  const [selectedRequest, setSelectedRequest] = useState<JoinRequest | null>(null);
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [requests, setRequests] = useState(mockRequests);

  const handleAccept = () => {
    if (selectedRequest) {
      setRequests(requests.map(r => 
        r.id === selectedRequest.id ? { ...r, status: 'accepted' as const } : r
      ));
      setShowRequestModal(false);
      setSelectedRequest(null);
    }
  };

  const handleReject = () => {
    if (selectedRequest) {
      setRequests(requests.map(r => 
        r.id === selectedRequest.id ? { ...r, status: 'rejected' as const } : r
      ));
      setShowRequestModal(false);
      setSelectedRequest(null);
    }
  };

  const getTeamRequests = (teamId: string) => {
    return requests.filter(r => r.teamId === teamId);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-8">
      <Navigation 
        user={user} 
        currentPage="created-teams" 
        onNavigate={onNavigate}
        onSignOut={onSignOut}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-gray-900 mb-2">My Created Teams</h1>
          <p className="text-gray-600">Manage your teams and review join requests</p>
        </div>

        {mockTeams.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center shadow-sm">
            <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-gray-900 mb-2">No Teams Yet</h3>
            <p className="text-gray-600 mb-6">
              Create your first team to start building something amazing
            </p>
            <Button onClick={() => onNavigate('create-team')}>
              Create Team
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            {mockTeams.map((team) => {
              const teamRequests = getTeamRequests(team.id);
              const pendingRequests = teamRequests.filter(r => r.status === 'pending');

              return (
                <div key={team.id} className="bg-white rounded-2xl p-6 shadow-sm">
                  {/* Team Header */}
                  <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-6 pb-6 border-b">
                    <div className="flex-1">
                      <h2 className="text-gray-900 mb-2">{team.name}</h2>
                      <p className="text-sm text-gray-600 mb-3">{team.hackathon}</p>
                      <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4" />
                          <span>{team.members.length}/{team.maxMembers} members</span>
                        </div>
                        {pendingRequests.length > 0 && (
                          <div className="flex items-center gap-2 text-orange-600">
                            <Clock className="w-4 h-4" />
                            <span>{pendingRequests.length} pending requests</span>
                          </div>
                        )}
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => onNavigate('team-details', team)}
                    >
                      View Team
                    </Button>
                  </div>

                  {/* Join Requests */}
                  {teamRequests.length > 0 ? (
                    <div>
                      <h3 className="text-gray-900 mb-4">Join Requests</h3>
                      <div className="space-y-3">
                        {teamRequests.map((request) => (
                          <div
                            key={request.id}
                            className="flex items-start gap-4 p-4 rounded-xl bg-gray-50"
                          >
                            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#1E90FF] to-[#0EA5A4] flex items-center justify-center flex-shrink-0">
                              <span className="text-white">{request.user.name.charAt(0)}</span>
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between gap-2 mb-1">
                                <div>
                                  <h4 className="text-gray-900">{request.user.name}</h4>
                                  <p className="text-sm text-gray-600">
                                    {request.user.major} • {request.user.year} • {request.user.college}
                                  </p>
                                </div>
                                {request.status === 'pending' && (
                                  <Badge variant="secondary">
                                    <Clock className="w-3 h-3 mr-1" />
                                    Pending
                                  </Badge>
                                )}
                                {request.status === 'accepted' && (
                                  <Badge className="bg-green-100 text-green-700 border-0">
                                    <CheckCircle className="w-3 h-3 mr-1" />
                                    Accepted
                                  </Badge>
                                )}
                                {request.status === 'rejected' && (
                                  <Badge variant="destructive">
                                    <XCircle className="w-3 h-3 mr-1" />
                                    Declined
                                  </Badge>
                                )}
                              </div>
                              <div className="flex flex-wrap gap-1 mb-2">
                                {request.user.skills.map((skill, idx) => (
                                  <span
                                    key={idx}
                                    className="px-2 py-0.5 bg-white rounded text-xs text-gray-600"
                                  >
                                    {skill}
                                  </span>
                                ))}
                              </div>
                              <p className="text-sm text-gray-600 line-clamp-2 mb-3">
                                {request.message}
                              </p>
                              {request.status === 'pending' && (
                                <div className="flex gap-2">
                                  <Button
                                    size="sm"
                                    onClick={() => {
                                      setSelectedRequest(request);
                                      setSelectedTeam(team);
                                      setShowRequestModal(true);
                                    }}
                                  >
                                    Review Request
                                  </Button>
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-gray-500 text-sm">No join requests yet</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </main>

      {/* Review Request Modal */}
      {selectedRequest && (
        <Dialog open={showRequestModal} onOpenChange={setShowRequestModal}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Review Join Request</DialogTitle>
              <DialogDescription>
                {selectedRequest.user.name} wants to join {selectedTeam?.name}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6 py-4">
              {/* User Profile */}
              <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-xl">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#1E90FF] to-[#0EA5A4] flex items-center justify-center flex-shrink-0">
                  <span className="text-white text-xl">{selectedRequest.user.name.charAt(0)}</span>
                </div>
                <div className="flex-1">
                  <h3 className="text-gray-900 mb-1">{selectedRequest.user.name}</h3>
                  <p className="text-sm text-gray-600 mb-3">
                    {selectedRequest.user.major} • {selectedRequest.user.year} • {selectedRequest.user.college}
                  </p>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {selectedRequest.user.skills.map((skill, idx) => (
                      <Badge key={idx} variant="secondary">{skill}</Badge>
                    ))}
                  </div>
                  {selectedRequest.user.bio && (
                    <p className="text-sm text-gray-600">{selectedRequest.user.bio}</p>
                  )}
                </div>
              </div>

              {/* Message */}
              <div>
                <h4 className="text-sm text-gray-700 mb-2">Message from {selectedRequest.user.name.split(' ')[0]}</h4>
                <div className="p-4 bg-blue-50 rounded-xl">
                  <p className="text-gray-700">{selectedRequest.message}</p>
                </div>
              </div>

              {/* Warning */}
              <div className="flex gap-3 p-4 bg-amber-50 rounded-xl">
                <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm">
                  <p className="text-amber-900">
                    <strong>Before accepting:</strong> Make sure this person is a good fit for your team. 
                    You can view their full profile and reach out before making a decision.
                  </p>
                </div>
              </div>
            </div>

            <DialogFooter className="gap-2">
              <Button
                variant="outline"
                onClick={handleReject}
                className="flex-1"
              >
                Decline Request
              </Button>
              <Button
                onClick={handleAccept}
                className="flex-1"
              >
                Accept to Team
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
