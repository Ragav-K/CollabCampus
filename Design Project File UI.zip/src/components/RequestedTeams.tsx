import { User, Team, JoinRequest } from '../App';
import { Navigation } from './Navigation';
import { Clock, CheckCircle, XCircle, Users } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';

type RequestedTeamsProps = {
  user: User;
  onNavigate: (page: any, team?: Team) => void;
  onSignOut: () => void;
};

const mockRequests: JoinRequest[] = [
  {
    id: '1',
    teamId: '1',
    userId: '1',
    user: {
      id: '1',
      name: 'Alex Johnson',
      email: 'alex@mit.edu',
      college: 'MIT',
      major: 'CS',
      year: 'Junior',
      skills: ['React'],
      bio: '',
    },
    message: 'I have experience with React and would love to contribute to the frontend!',
    status: 'pending',
    createdAt: new Date('2025-01-16'),
  },
  {
    id: '2',
    teamId: '2',
    userId: '1',
    user: {
      id: '1',
      name: 'Alex Johnson',
      email: 'alex@mit.edu',
      college: 'MIT',
      major: 'CS',
      year: 'Junior',
      skills: ['React'],
      bio: '',
    },
    message: 'This sounds like an exciting project! I\'d love to help build the platform.',
    status: 'accepted',
    createdAt: new Date('2025-01-14'),
  },
  {
    id: '3',
    teamId: '3',
    userId: '1',
    user: {
      id: '1',
      name: 'Alex Johnson',
      email: 'alex@mit.edu',
      college: 'MIT',
      major: 'CS',
      year: 'Junior',
      skills: ['React'],
      bio: '',
    },
    message: 'I have UI/UX experience and can help with the design implementation.',
    status: 'rejected',
    createdAt: new Date('2025-01-12'),
  },
];

const mockTeams: Record<string, Team> = {
  '1': {
    id: '1',
    name: 'AI Healthcare Innovators',
    hackathon: 'MIT Health Hack 2025',
    description: 'Building an AI diagnostic assistant',
    skills: ['ML', 'Python'],
    lookingFor: ['Frontend Developer'],
    members: [],
    maxMembers: 4,
    createdBy: '2',
    createdAt: new Date('2025-01-10'),
  },
  '2': {
    id: '2',
    name: 'Sustainable Campus',
    hackathon: 'Green Tech Challenge',
    description: 'Carbon footprint tracking platform',
    skills: ['React', 'Node.js'],
    lookingFor: ['Full Stack Developer'],
    members: [],
    maxMembers: 3,
    createdBy: '4',
    createdAt: new Date('2025-01-12'),
  },
  '3': {
    id: '3',
    name: 'EduGame Builders',
    hackathon: 'Education Innovation Summit',
    description: 'Gamifying STEM education',
    skills: ['Unity', 'C#'],
    lookingFor: ['UI/UX Designer'],
    members: [],
    maxMembers: 4,
    createdBy: '7',
    createdAt: new Date('2025-01-14'),
  },
};

export function RequestedTeams({ user, onNavigate, onSignOut }: RequestedTeamsProps) {
  const pendingRequests = mockRequests.filter(r => r.status === 'pending');
  const acceptedRequests = mockRequests.filter(r => r.status === 'accepted');
  const rejectedRequests = mockRequests.filter(r => r.status === 'rejected');

  const renderRequest = (request: JoinRequest) => {
    const team = mockTeams[request.teamId];
    if (!team) return null;

    return (
      <div key={request.id} className="bg-white rounded-2xl p-6 shadow-sm">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div className="flex-1">
            <div className="flex items-start gap-2 mb-2">
              <h3 className="text-gray-900">{team.name}</h3>
              {request.status === 'pending' && (
                <Badge variant="secondary">
                  <Clock className="w-3 h-3 mr-1" />
                  Pending
                </Badge>
              )}
              {request.status === 'accepted' && (
                <Badge className="bg-green-100 text-green-700 border-0">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Accepted
                </Badge>
              )}
              {request.status === 'rejected' && (
                <Badge variant="destructive">
                  <XCircle className="w-3 h-3 mr-1" />
                  Declined
                </Badge>
              )}
            </div>
            <p className="text-sm text-gray-600 mb-3">{team.hackathon}</p>
          </div>
        </div>

        <div className="mb-4">
          <p className="text-sm text-gray-700 mb-2">Your message:</p>
          <div className="p-3 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600">{request.message}</p>
          </div>
        </div>

        <div className="flex items-center justify-between pt-4 border-t">
          <p className="text-xs text-gray-500">
            Sent {Math.floor((new Date().getTime() - request.createdAt.getTime()) / (1000 * 60 * 60 * 24))} days ago
          </p>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigate('team-details', team)}
          >
            View Team
          </Button>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-8">
      <Navigation 
        user={user} 
        currentPage="requested-teams" 
        onNavigate={onNavigate}
        onSignOut={onSignOut}
      />

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-gray-900 mb-2">My Join Requests</h1>
          <p className="text-gray-600">Track your team join request status</p>
        </div>

        {mockRequests.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center shadow-sm">
            <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-gray-900 mb-2">No Requests Yet</h3>
            <p className="text-gray-600 mb-6">
              Start exploring teams and send join requests to get started
            </p>
            <Button onClick={() => onNavigate('join-team')}>
              Find Teams
            </Button>
          </div>
        ) : (
          <div className="space-y-8">
            {/* Pending */}
            {pendingRequests.length > 0 && (
              <div>
                <h2 className="text-gray-900 mb-4">
                  Pending ({pendingRequests.length})
                </h2>
                <div className="space-y-4">
                  {pendingRequests.map(renderRequest)}
                </div>
              </div>
            )}

            {/* Accepted */}
            {acceptedRequests.length > 0 && (
              <div>
                <h2 className="text-gray-900 mb-4">
                  Accepted ({acceptedRequests.length})
                </h2>
                <div className="space-y-4">
                  {acceptedRequests.map(renderRequest)}
                </div>
              </div>
            )}

            {/* Rejected */}
            {rejectedRequests.length > 0 && (
              <div>
                <h2 className="text-gray-900 mb-4">
                  Declined ({rejectedRequests.length})
                </h2>
                <div className="space-y-4">
                  {rejectedRequests.map(renderRequest)}
                </div>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
