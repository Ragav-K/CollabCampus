import { useState } from 'react';
import { User } from '../App';
import { Navigation } from './Navigation';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Bell, Mail, Shield, Trash2, AlertCircle } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Alert, AlertDescription } from './ui/alert';

type SettingsProps = {
  user: User;
  onNavigate: (page: any) => void;
  onSignOut: () => void;
};

export function Settings({ user, onNavigate, onSignOut }: SettingsProps) {
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [pushNotifications, setPushNotifications] = useState(true);
  const [joinRequests, setJoinRequests] = useState(true);
  const [teamUpdates, setTeamUpdates] = useState(true);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-8">
      <Navigation 
        user={user} 
        currentPage="settings" 
        onNavigate={onNavigate}
        onSignOut={onSignOut}
      />

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-gray-900 mb-2">Settings</h1>
          <p className="text-gray-600">Manage your account preferences</p>
        </div>

        {/* Notifications */}
        <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm mb-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
              <Bell className="w-5 h-5 text-[#1E90FF]" />
            </div>
            <div>
              <h2 className="text-gray-900">Notifications</h2>
              <p className="text-sm text-gray-600">Choose how you want to be notified</p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <Label htmlFor="email-notifications">Email Notifications</Label>
                <p className="text-sm text-gray-600">Receive updates via email</p>
              </div>
              <Switch
                id="email-notifications"
                checked={emailNotifications}
                onCheckedChange={setEmailNotifications}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex-1">
                <Label htmlFor="push-notifications">Push Notifications</Label>
                <p className="text-sm text-gray-600">Get real-time alerts</p>
              </div>
              <Switch
                id="push-notifications"
                checked={pushNotifications}
                onCheckedChange={setPushNotifications}
              />
            </div>

            <div className="border-t pt-6">
              <h3 className="text-gray-900 mb-4">Notification Types</h3>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <Label htmlFor="join-requests">Join Requests</Label>
                    <p className="text-sm text-gray-600">When someone wants to join your team</p>
                  </div>
                  <Switch
                    id="join-requests"
                    checked={joinRequests}
                    onCheckedChange={setJoinRequests}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <Label htmlFor="team-updates">Team Updates</Label>
                    <p className="text-sm text-gray-600">Updates from teams you're in</p>
                  </div>
                  <Switch
                    id="team-updates"
                    checked={teamUpdates}
                    onCheckedChange={setTeamUpdates}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Privacy */}
        <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm mb-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-purple-100 flex items-center justify-center">
              <Shield className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <h2 className="text-gray-900">Privacy & Security</h2>
              <p className="text-sm text-gray-600">Control your data and visibility</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="p-4 bg-gray-50 rounded-xl">
              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-gray-600 mt-0.5" />
                <div>
                  <h3 className="text-gray-900 mb-1">Verified Email</h3>
                  <p className="text-sm text-gray-600">{user.email}</p>
                </div>
              </div>
            </div>

            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Your profile is visible to all verified college students on CollabCampus. 
                This helps you connect with potential teammates.
              </AlertDescription>
            </Alert>
          </div>
        </div>

        {/* Account Actions */}
        <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center">
              <Trash2 className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <h2 className="text-gray-900">Danger Zone</h2>
              <p className="text-sm text-gray-600">Irreversible account actions</p>
            </div>
          </div>

          <div className="space-y-4">
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Deleting your account will permanently remove all your data, teams, and requests. 
                This action cannot be undone.
              </AlertDescription>
            </Alert>

            <Button
              variant="destructive"
              onClick={() => setShowDeleteDialog(true)}
              className="gap-2"
            >
              <Trash2 className="w-4 h-4" />
              Delete Account
            </Button>
          </div>
        </div>
      </main>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Account?</DialogTitle>
            <DialogDescription>
              This action cannot be undone. All your data will be permanently deleted.
            </DialogDescription>
          </DialogHeader>

          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              You will lose access to:
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>All your created teams</li>
                <li>Your join requests</li>
                <li>Your profile and connections</li>
              </ul>
            </AlertDescription>
          </Alert>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowDeleteDialog(false)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                // Handle account deletion
                setShowDeleteDialog(false);
                onSignOut();
              }}
            >
              Yes, Delete My Account
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
