import { Users, Zap, Shield, ArrowRight } from 'lucide-react';
import { Button } from './ui/button';

type LandingProps = {
  onNavigate: (page: 'signin' | 'signup') => void;
};

export function Landing({ onNavigate }: LandingProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-teal-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#1E90FF] to-[#0EA5A4] flex items-center justify-center">
              <Users className="w-5 h-5 text-white" />
            </div>
            <span className="text-gray-900">CollabCampus</span>
          </div>
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              onClick={() => onNavigate('signin')}
              className="hidden sm:flex"
            >
              Sign In
            </Button>
            <Button onClick={() => onNavigate('signup')}>
              Get Started
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
        <div className="text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-100 text-[#1E90FF] mb-8">
            <Zap className="w-4 h-4" />
            <span className="text-sm">Real-time team formation</span>
          </div>
          <h1 className="text-gray-900 mb-6">
            Find Your Perfect Hackathon Team in Minutes
          </h1>
          <p className="text-gray-600 mb-12 max-w-2xl mx-auto">
            Join thousands of college students discovering teammates, building amazing projects, 
            and winning hackathons together. No more solo struggles.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button 
              size="lg" 
              onClick={() => onNavigate('signup')}
              className="w-full sm:w-auto group"
            >
              Create Your Profile
              <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              onClick={() => onNavigate('signin')}
              className="w-full sm:w-auto"
            >
              Sign In
            </Button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid sm:grid-cols-3 gap-8">
          <div className="bg-white rounded-2xl p-8 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center mb-4">
              <Zap className="w-6 h-6 text-[#1E90FF]" />
            </div>
            <h3 className="text-gray-900 mb-2">Fast Discovery</h3>
            <p className="text-gray-600 text-sm">
              Browse teams instantly with smart filters. Find the perfect match based on skills, 
              hackathon, and interests.
            </p>
          </div>
          <div className="bg-white rounded-2xl p-8 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-teal-100 flex items-center justify-center mb-4">
              <Users className="w-6 h-6 text-[#0EA5A4]" />
            </div>
            <h3 className="text-gray-900 mb-2">Easy Team Formation</h3>
            <p className="text-gray-600 text-sm">
              Create your team in seconds. Manage join requests and build your dream squad 
              effortlessly.
            </p>
          </div>
          <div className="bg-white rounded-2xl p-8 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center mb-4">
              <Shield className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-gray-900 mb-2">Trust & Safety</h3>
            <p className="text-gray-600 text-sm">
              College email verification ensures you're connecting with real students. 
              Build trust through detailed profiles.
            </p>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="bg-gradient-to-br from-[#1E90FF] to-[#0EA5A4] rounded-3xl p-12 text-center">
          <h2 className="text-white mb-4">Ready to Join Your Next Team?</h2>
          <p className="text-blue-100 mb-8 max-w-2xl mx-auto">
            Start connecting with talented students from your college and beyond.
          </p>
          <Button 
            size="lg" 
            variant="secondary"
            onClick={() => onNavigate('signup')}
            className="bg-white text-[#1E90FF] hover:bg-gray-50"
          >
            Sign Up with College Email
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-white mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-[#1E90FF] to-[#0EA5A4] flex items-center justify-center">
                <Users className="w-4 h-4 text-white" />
              </div>
              <span className="text-gray-600 text-sm">CollabCampus</span>
            </div>
            <p className="text-gray-500 text-sm">
              © 2025 CollabCampus. Built for college hackers.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
