import { User, Team } from '../App';
import { Navigation } from './Navigation';
import { TeamCard } from './TeamCard';
import { PlusCircle, Users, TrendingUp, Clock } from 'lucide-react';
import { Button } from './ui/button';

type DashboardProps = {
  user: User;
  onNavigate: (page: any, team?: Team) => void;
  onSignOut: () => void;
};

const mockTeams: Team[] = [
  {
    id: '1',
    name: 'AI Healthcare Innovators',
    hackathon: 'MIT Health Hack 2025',
    description: 'Building an AI-powered diagnostic assistant to help rural healthcare workers make better decisions.',
    skills: ['Machine Learning', 'Python', 'Healthcare'],
    lookingFor: ['Backend Developer', 'UI/UX Designer'],
    members: [
      { id: '2', name: 'Sarah Chen', email: 'sarah@mit.edu', college: 'MIT', major: 'AI', year: 'Senior', skills: ['ML', 'Python'], bio: '' },
      { id: '3', name: 'Mike Wilson', email: 'mike@mit.edu', college: 'MIT', major: 'CS', year: 'Junior', skills: ['Python'], bio: '' },
    ],
    maxMembers: 4,
    createdBy: '2',
    createdAt: new Date('2025-01-10'),
  },
  {
    id: '2',
    name: 'Sustainable Campus',
    hackathon: 'Green Tech Challenge',
    description: 'Creating a platform to track and reduce carbon footprint on college campuses.',
    skills: ['React', 'Node.js', 'Data Viz'],
    lookingFor: ['Full Stack Developer'],
    members: [
      { id: '4', name: 'Emily Davis', email: 'emily@stanford.edu', college: 'Stanford', major: 'Environmental Science', year: 'Sophomore', skills: ['React'], bio: '' },
    ],
    maxMembers: 3,
    createdBy: '4',
    createdAt: new Date('2025-01-12'),
  },
  {
    id: '3',
    name: 'FinTech Wizards',
    hackathon: 'HackMoney 2025',
    description: 'Building a peer-to-peer lending platform for college students.',
    skills: ['Blockchain', 'Solidity', 'React'],
    lookingFor: ['Smart Contract Developer', 'Frontend Dev'],
    members: [
      { id: '5', name: 'James Lee', email: 'james@berkeley.edu', college: 'UC Berkeley', major: 'Finance', year: 'Junior', skills: ['Blockchain'], bio: '' },
      { id: '6', name: 'Lisa Park', email: 'lisa@berkeley.edu', college: 'UC Berkeley', major: 'CS', year: 'Senior', skills: ['Solidity'], bio: '' },
    ],
    maxMembers: 4,
    createdBy: '5',
    createdAt: new Date('2025-01-15'),
  },
];

export function Dashboard({ user, onNavigate, onSignOut }: DashboardProps) {
  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-8">
      <Navigation 
        user={user} 
        currentPage="dashboard" 
        onNavigate={onNavigate}
        onSignOut={onSignOut}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-gray-900 mb-2">Welcome back, {user.name.split(' ')[0]}! 👋</h1>
          <p className="text-gray-600">Find your perfect hackathon team or create your own</p>
        </div>

        {/* Quick Stats */}
        <div className="grid sm:grid-cols-3 gap-4 mb-8">
          <div className="bg-white rounded-2xl p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
                <Users className="w-5 h-5 text-[#1E90FF]" />
              </div>
              <div>
                <p className="text-2xl text-gray-900">2</p>
                <p className="text-sm text-gray-600">Teams Created</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-teal-100 flex items-center justify-center">
                <Clock className="w-5 h-5 text-[#0EA5A4]" />
              </div>
              <div>
                <p className="text-2xl text-gray-900">3</p>
                <p className="text-sm text-gray-600">Pending Requests</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-purple-100 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl text-gray-900">12</p>
                <p className="text-sm text-gray-600">Profile Views</p>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-gradient-to-br from-[#1E90FF] to-[#0EA5A4] rounded-2xl p-6 sm:p-8 mb-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-white mb-2">Ready to start a new team?</h2>
              <p className="text-blue-100">Create your team in less than 2 minutes</p>
            </div>
            <Button 
              size="lg"
              variant="secondary"
              onClick={() => onNavigate('create-team')}
              className="bg-white text-[#1E90FF] hover:bg-gray-50 gap-2 whitespace-nowrap"
            >
              <PlusCircle className="w-5 h-5" />
              Create Team
            </Button>
          </div>
        </div>

        {/* Recommended Teams */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-gray-900">Recommended Teams</h2>
            <Button 
              variant="ghost" 
              onClick={() => onNavigate('join-team')}
            >
              View All
            </Button>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {mockTeams.map((team) => (
              <TeamCard 
                key={team.id} 
                team={team}
                onClick={() => onNavigate('team-details', team)}
              />
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
