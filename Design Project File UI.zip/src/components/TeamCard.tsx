import { Team } from '../App';
import { Users, Calendar, MapPin } from 'lucide-react';
import { Badge } from './ui/badge';

type TeamCardProps = {
  team: Team;
  onClick: () => void;
};

export function TeamCard({ team, onClick }: TeamCardProps) {
  const spotsLeft = team.maxMembers - team.members.length;
  const daysAgo = Math.floor((new Date().getTime() - team.createdAt.getTime()) / (1000 * 60 * 60 * 24));

  return (
    <button
      onClick={onClick}
      className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-md transition-all text-left w-full group"
    >
      <div className="flex items-start justify-between mb-3">
        <h3 className="text-gray-900 group-hover:text-[#1E90FF] transition-colors">
          {team.name}
        </h3>
        {spotsLeft > 0 && (
          <Badge variant="secondary" className="bg-green-100 text-green-700 border-0">
            {spotsLeft} {spotsLeft === 1 ? 'spot' : 'spots'}
          </Badge>
        )}
      </div>

      <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
        <MapPin className="w-4 h-4" />
        <span>{team.hackathon}</span>
      </div>

      <p className="text-sm text-gray-600 mb-4 line-clamp-2">
        {team.description}
      </p>

      <div className="flex flex-wrap gap-2 mb-4">
        {team.lookingFor.slice(0, 2).map((role, idx) => (
          <Badge key={idx} variant="outline" className="text-xs">
            Looking for: {role}
          </Badge>
        ))}
        {team.lookingFor.length > 2 && (
          <Badge variant="outline" className="text-xs">
            +{team.lookingFor.length - 2} more
          </Badge>
        )}
      </div>

      <div className="flex items-center justify-between pt-4 border-t">
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <Users className="w-4 h-4" />
          <span>{team.members.length}/{team.maxMembers} members</span>
        </div>
        <div className="flex items-center gap-2 text-xs text-gray-500">
          <Calendar className="w-3 h-3" />
          <span>{daysAgo === 0 ? 'Today' : `${daysAgo}d ago`}</span>
        </div>
      </div>
    </button>
  );
}
