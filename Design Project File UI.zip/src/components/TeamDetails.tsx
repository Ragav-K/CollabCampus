import { useState } from 'react';
import { User, Team } from '../App';
import { Navigation } from './Navigation';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { ArrowLeft, Users, Calendar, MapPin, Send, CheckCircle2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';

type TeamDetailsProps = {
  user: User;
  team: Team;
  onNavigate: (page: any) => void;
  onSignOut: () => void;
};

export function TeamDetails({ user, team, onNavigate, onSignOut }: TeamDetailsProps) {
  const [showJoinModal, setShowJoinModal] = useState(false);
  const [joinMessage, setJoinMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const spotsLeft = team.maxMembers - team.members.length;
  const daysAgo = Math.floor((new Date().getTime() - team.createdAt.getTime()) / (1000 * 60 * 60 * 24));

  const handleJoinRequest = () => {
    setIsSubmitted(true);
    setTimeout(() => {
      setShowJoinModal(false);
      setIsSubmitted(false);
      setJoinMessage('');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-8">
      <Navigation 
        user={user} 
        currentPage="join-team" 
        onNavigate={onNavigate}
        onSignOut={onSignOut}
      />

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={() => onNavigate('join-team')}
          className="mb-6 gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Teams
        </Button>

        {/* Team Header */}
        <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm mb-6">
          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-6">
            <div className="flex-1">
              <div className="flex items-start gap-3 mb-3">
                <h1 className="text-gray-900">{team.name}</h1>
                {spotsLeft > 0 && (
                  <Badge className="bg-green-100 text-green-700 border-0">
                    {spotsLeft} {spotsLeft === 1 ? 'spot' : 'spots'} left
                  </Badge>
                )}
              </div>

              <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-4">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  <span>{team.hackathon}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  <span>Created {daysAgo === 0 ? 'today' : `${daysAgo} days ago`}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  <span>{team.members.length}/{team.maxMembers} members</span>
                </div>
              </div>
            </div>

            {spotsLeft > 0 && (
              <Button
                size="lg"
                onClick={() => setShowJoinModal(true)}
                className="gap-2 whitespace-nowrap"
              >
                <Send className="w-4 h-4" />
                Request to Join
              </Button>
            )}
          </div>

          {/* Description */}
          <div className="mb-6">
            <h3 className="text-gray-900 mb-2">About the Project</h3>
            <p className="text-gray-600">{team.description}</p>
          </div>

          {/* Looking For */}
          {team.lookingFor.length > 0 && (
            <div className="mb-6">
              <h3 className="text-gray-900 mb-3">Looking For</h3>
              <div className="flex flex-wrap gap-2">
                {team.lookingFor.map((role, idx) => (
                  <Badge key={idx} variant="outline" className="text-sm">
                    {role}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Skills */}
          <div>
            <h3 className="text-gray-900 mb-3">Team Skills</h3>
            <div className="flex flex-wrap gap-2">
              {team.skills.map((skill, idx) => (
                <Badge key={idx} variant="secondary">
                  {skill}
                </Badge>
              ))}
            </div>
          </div>
        </div>

        {/* Team Members */}
        <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm">
          <h2 className="text-gray-900 mb-4">Team Members ({team.members.length})</h2>
          
          <div className="space-y-4">
            {team.members.map((member) => (
              <div
                key={member.id}
                className="flex items-start gap-4 p-4 rounded-xl bg-gray-50 hover:bg-gray-100 transition-colors"
              >
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#1E90FF] to-[#0EA5A4] flex items-center justify-center flex-shrink-0">
                  <span className="text-white">{member.name.charAt(0)}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <h3 className="text-gray-900">{member.name}</h3>
                    {member.id === team.createdBy && (
                      <Badge variant="secondary" className="text-xs">Team Lead</Badge>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 mb-2">
                    {member.major} • {member.year} • {member.college}
                  </p>
                  <div className="flex flex-wrap gap-1">
                    {member.skills.map((skill, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 bg-white rounded text-xs text-gray-600"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Join Request Modal */}
      <Dialog open={showJoinModal} onOpenChange={setShowJoinModal}>
        <DialogContent>
          {!isSubmitted ? (
            <>
              <DialogHeader>
                <DialogTitle>Request to Join {team.name}</DialogTitle>
                <DialogDescription>
                  Introduce yourself and explain why you'd be a great fit for this team
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="message">Your Message</Label>
                  <Textarea
                    id="message"
                    placeholder="Hi! I'm interested in joining your team because..."
                    value={joinMessage}
                    onChange={(e) => setJoinMessage(e.target.value)}
                    rows={5}
                    className="resize-none"
                  />
                  <p className="text-xs text-gray-500">
                    The team lead will review your profile and message
                  </p>
                </div>

                {/* Your Profile Preview */}
                <div className="p-4 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-600 mb-2">Your profile preview:</p>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#1E90FF] to-[#0EA5A4] flex items-center justify-center">
                      <span className="text-white text-sm">{user.name.charAt(0)}</span>
                    </div>
                    <div>
                      <p className="text-sm text-gray-900">{user.name}</p>
                      <p className="text-xs text-gray-600">{user.major} • {user.year}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setShowJoinModal(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleJoinRequest}
                  disabled={!joinMessage.trim()}
                  className="flex-1"
                >
                  Send Request
                </Button>
              </div>
            </>
          ) : (
            <div className="py-8 text-center">
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-gray-900 mb-2">Request Sent!</h3>
              <p className="text-gray-600 text-sm">
                The team lead will review your request soon
              </p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
