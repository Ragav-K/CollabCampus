import { Home, Search, PlusCircle, Users as UsersIcon, Bell, User as UserIcon, Settings as SettingsIcon, LogOut, Menu, X } from 'lucide-react';
import { User } from '../App';
import { useState } from 'react';
import { Button } from './ui/button';

type Page = 
  | 'dashboard' 
  | 'join-team' 
  | 'create-team' 
  | 'created-teams'
  | 'requested-teams'
  | 'notifications'
  | 'profile'
  | 'settings';

type NavigationProps = {
  user: User;
  currentPage: Page;
  onNavigate: (page: Page) => void;
  onSignOut: () => void;
  notificationCount?: number;
};

export function Navigation({ user, currentPage, onNavigate, onSignOut, notificationCount = 3 }: NavigationProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { page: 'dashboard' as Page, icon: Home, label: 'Home' },
    { page: 'join-team' as Page, icon: Search, label: 'Find Teams' },
    { page: 'create-team' as Page, icon: PlusCircle, label: 'Create Team' },
    { page: 'created-teams' as Page, icon: UsersIcon, label: 'My Teams' },
  ];

  return (
    <>
      {/* Desktop Header */}
      <header className="hidden md:block border-b bg-white sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <button 
              onClick={() => onNavigate('dashboard')}
              className="flex items-center gap-2 hover:opacity-80 transition-opacity"
            >
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#1E90FF] to-[#0EA5A4] flex items-center justify-center">
                <UsersIcon className="w-5 h-5 text-white" />
              </div>
              <span className="text-gray-900">CollabCampus</span>
            </button>

            <nav className="flex items-center gap-2">
              {navItems.map((item) => (
                <Button
                  key={item.page}
                  variant={currentPage === item.page ? 'default' : 'ghost'}
                  onClick={() => onNavigate(item.page)}
                  className="gap-2"
                >
                  <item.icon className="w-4 h-4" />
                  {item.label}
                </Button>
              ))}
            </nav>

            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigate('notifications')}
                className="relative p-2 hover:bg-gray-100 rounded-lg transition-colors"
                aria-label="Notifications"
              >
                <Bell className="w-5 h-5 text-gray-600" />
                {notificationCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                    {notificationCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => onNavigate('profile')}
                className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#1E90FF] to-[#0EA5A4] flex items-center justify-center">
                  <span className="text-white text-sm">{user.name.charAt(0)}</span>
                </div>
              </button>

              <button
                onClick={() => onNavigate('settings')}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                aria-label="Settings"
              >
                <SettingsIcon className="w-5 h-5 text-gray-600" />
              </button>

              <button
                onClick={onSignOut}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors text-red-600"
                aria-label="Sign out"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Header */}
      <header className="md:hidden border-b bg-white sticky top-0 z-40">
        <div className="px-4 py-4">
          <div className="flex items-center justify-between">
            <button 
              onClick={() => onNavigate('dashboard')}
              className="flex items-center gap-2"
            >
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#1E90FF] to-[#0EA5A4] flex items-center justify-center">
                <UsersIcon className="w-5 h-5 text-white" />
              </div>
              <span className="text-gray-900">CollabCampus</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigate('notifications')}
                className="relative p-2 hover:bg-gray-100 rounded-lg"
                aria-label="Notifications"
              >
                <Bell className="w-5 h-5 text-gray-600" />
                {notificationCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                    {notificationCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 hover:bg-gray-100 rounded-lg"
                aria-label="Menu"
              >
                {mobileMenuOpen ? (
                  <X className="w-6 h-6 text-gray-600" />
                ) : (
                  <Menu className="w-6 h-6 text-gray-600" />
                )}
              </button>
            </div>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <nav className="mt-4 pt-4 border-t space-y-1">
              {navItems.map((item) => (
                <button
                  key={item.page}
                  onClick={() => {
                    onNavigate(item.page);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    currentPage === item.page
                      ? 'bg-blue-50 text-[#1E90FF]'
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </button>
              ))}

              <div className="border-t pt-2 mt-2">
                <button
                  onClick={() => {
                    onNavigate('profile');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  <UserIcon className="w-5 h-5" />
                  <span>Profile</span>
                </button>
                <button
                  onClick={() => {
                    onNavigate('settings');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  <SettingsIcon className="w-5 h-5" />
                  <span>Settings</span>
                </button>
                <button
                  onClick={onSignOut}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-red-600 hover:bg-red-50"
                >
                  <LogOut className="w-5 h-5" />
                  <span>Sign Out</span>
                </button>
              </div>
            </nav>
          )}
        </div>
      </header>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t z-40">
        <div className="grid grid-cols-4 gap-1">
          {navItems.map((item) => (
            <button
              key={item.page}
              onClick={() => onNavigate(item.page)}
              className={`flex flex-col items-center gap-1 py-3 transition-colors ${
                currentPage === item.page
                  ? 'text-[#1E90FF]'
                  : 'text-gray-600'
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span className="text-xs">{item.label}</span>
            </button>
          ))}
        </div>
      </nav>
    </>
  );
}
